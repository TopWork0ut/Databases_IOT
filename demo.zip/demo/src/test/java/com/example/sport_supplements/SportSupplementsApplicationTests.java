package com.example.sport_supplements;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportSupplementsApplicationTests {

	@Test
	void contextLoads() {
	}

}
