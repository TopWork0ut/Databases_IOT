package com.example.sport_supplements;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportSupplementsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportSupplementsApplication.class, args);
	}

}
